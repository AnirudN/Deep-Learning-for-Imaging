This is the submission done by Anirud N CE21B014 for assignment 1.

Assignment-1 _DLI_CE21B014_AnirudN.pdf is the report that specifies the details and the inferences of the findings.

There are 4 .ipynb files :
1) Sigmoid_scratch - contains from the scratch implementation of the MLP for MNIST Data - and its results and plots 

2) relu_scratch - for relu activation function


3) TanH_scratch - for tanh activation function

4) pytorch_replication - contains the pytorch implementation of sigmoid activation function MLP and Tanh activation function MLP using adams optimiser.

5) pytorch_l2_regularisation - the constrained optimisation ie regularisation code with pytorch. 

